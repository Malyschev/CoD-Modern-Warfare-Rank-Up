There's 2 ways to install
 1. Throw mods in your custom folder
 2. Throw vpk file in your custom folder